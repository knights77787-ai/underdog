# Underdog AI Backend (FastAPI)

오늘 완료 목표(권장 마일스톤) 5개 구현.  
**카테고리(경고/일상생활)**는 ERD의 `event_type`(danger / alert / pass) 기준으로,  
`Shared/constants/event_types.json`에서 키워드 분류와 쿨다운을 수정할 수 있습니다.

## 실행

실제 앱 코드는 **App/main.py**에 있습니다. Backend 폴더에서:

```bash
cd Backend
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

(`main.py`가 `App.main`의 app을 불러와서 위처럼 실행하면 됩니다. 또는 `uvicorn App.main:app` 으로 직접 지정해도 됩니다.)
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

(`main.py`가 `App.main`의 app을 불러와서 위처럼 실행하면 됩니다. 또는 `uvicorn App.main:app` 으로 직접 지정해도 됩니다.)

브라우저에서 **http://localhost:8000/health** 접속 시 `{"ok": true}` 표시.

## 마일스톤 요약

| # | 항목 | 설명 |
|---|------|------|
| 1 | 서버/헬스체크 | `GET /health` → `{ "ok": true }` |
| 2 | WebSocket hello/ack | `/ws` 연결 시 서버가 `hello` 전송, 클라이언트 `hello` → 서버 `hello_ack` |
| 3 | caption 브로드캐스트 | `{ "type": "caption", "session_id": "S1", "text": "..." }` 전송 시 동일 세션 다른 클라이언트에게만 전달 |
| 4 | 키워드 감지 + alert | 키워드(불/비상/도와 등) 포함 시 `alert` push, 키워드별 5초 쿨다운 |
| 5 | 로그 조회 API | `GET /logs?type=caption\|alert\|all&limit=100&session_id=S1` (메모리, 최근 300건 유지) |

## WebSocket 사용 예

1. **연결**  
   `ws://localhost:8000/ws`  
   연결 직후 서버 → 클라이언트: `{ "type": "hello" }`

2. **세션 참가**  
   클라이언트 → 서버: `{ "type": "join", "session_id": "S1" }`

3. **자막 전송(브로드캐스트)**  
   클라이언트 → 서버: `{ "type": "caption", "session_id": "S1", "text": "지금 비상입니다." }`  
   동일 세션 다른 탭/클라이언트에게 동일 메시지 전달.  
   문장에 키워드(불/비상/도와 등)가 있으면 5초 쿨다운 적용 후 `{ "type": "alert", "keyword": "비상", ... }` 브로드캐스트.

## 로그 API

- `GET /logs?type=caption&limit=100`  
  최근 caption만 조회.
- `GET /logs?type=alert&limit=100`  
  최근 alert만 조회.
- `GET /logs?type=all&limit=100&session_id=S1`  
  caption/alert 모두, 세션 필터.
